class Product{
  String image;
  String name;
  String description;
  double price;

  Product(this.image, this.name, this.description, this.price);
}