package com.int2.ecommerce_int2

import io.flutter.embedding.android.FlutterActivity;
class MainActivity: FlutterActivity() {
}
